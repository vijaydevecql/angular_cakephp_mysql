<?php

App::uses('AppController', 'Controller');


class ApiController extends AppController {
	
	public function login() {
		$this->loadModel('User');
        try {
            if (!$this->request->is(array('POST'))) {
                throw new Exception('Only POST  supported');
            }
            $required = array(
                'email' => @$this->request->data['email'],
                'password' => @$this->request->data['password'],
                'checking_exits' => 0
            );
            $notrequired = array(
                'device_type' => @($this->request->data['device_type'] == '') ? 0 : $this->request->data['device_type'],
                'device_token' => @($this->request->data['device_token'] == '') ? '' : $this->request->data['device_token'],
                'authorization_key' => $this->_generate_random_number(),
            );
            $requestdata = $this->validarray($required, $notrequired);
            $options = ['conditions' => ['User.email' => $requestdata['email'], 'User.password' => $requestdata['password']]];
            //prx( $options );
            $user = $this->User->find('first', $options);

            if ($user) {
                if ($user['User']['status'] == 0) {
                    $status = SUCCESS_CODE;
                    $body = $this->information($user['User']['authorization_key']);
                    $this->json($status, $body);
                } else {
                    $requestdata['id'] = $user['User']['id'];
                    if ($this->User->save($requestdata, ['validate' => false])) {
                        $status = SUCCESS_CODE;
                        $body = $this->information($requestdata['authorization_key']);
                        $this->json($status, $body);
                    } else {
                        throw new Exception('Server Error');
                    }
                }
            } else {
                throw new Exception('Wrong Email or password');
            }
        } catch (Exception $ex) {
            $status = FAILURE_CODE;
            $body = $ex->getMessage();
            $this->json($status, $body);
        }
    }

    private function information($authorization_key) {
		$this->loadModel('User');
        if (count($authorization_key) == 0) {
            return false;
        }

        $options = ['conditions' => ['User.authorization_key' => $authorization_key]];
        $restaurant = $this->User->find('first', $options);
        // $restaurant['User']['image'] = strlen(trim($restaurant['User']['image'])) ? $this->_user_image_path($restaurant['User']['image']) : '';
        $restaurant['User']['user_type'] = 1;
        unset($restaurant['User']['password']);
        unset($restaurant['User']['ip_address']);
        unset($restaurant['User']['email_verified']);
        unset($restaurant['User']['phone_verified']);
        unset($restaurant['User']['status_facebook']);
        unset($restaurant['User']['status_twitter']);
        unset($restaurant['User']['forgot_password_hash']);
        unset($restaurant['User']['remember_me_hash']);
        unset($restaurant['User']['language_id']);
        unset($restaurant['User']['newsletter_subscription']);
        unset($restaurant['User']['otp']);
        unset($restaurant['User']['device_type']);
        unset($restaurant['User']['device_token']);
       return $restaurant['User'];
    }

    public function verify_otp() {
		$this->loadModel('User');
        try {
            if (!$this->request->is(array('POST'))) {
                throw new Exception('Only POST  supported');
            }
            $required = array(
                'authorization_key' => @$this->request->header('Authorization-key'),
                'otp' => @$this->request->data['otp'],
                'checking_exits' => 1
            );
            $notrequired = array(
                'device_type' => @($this->request->data['device_type'] == '') ? 0 : $this->request->data['device_type'],
                'device_token' => @($this->request->data['device_token'] == '') ? '' : $this->request->data['device_token']
            );
            $requestdata = $this->validarray($required, $notrequired);

            $options = ['conditions' => ['User.id' => $requestdata['user_id']]];
            $restaurant = $this->User->find('first', $options);

            if ($restaurant['User']['otp'] == $requestdata['otp']) {
                $requestdata['status'] = 1;
                $requestdata['id'] = $restaurant['User']['id'];
                if ($this->User->save($requestdata, ['validate' => false])) {
                    $status = SUCCESS_CODE;
                    $body = $this->information($requestdata['authorization_key']);
                    $this->json($status, $body);
                } else {
                    throw new Exception('Something Error to verfication account');
                }
            } else {
                throw new Exception('Wrong otp code');
            }
        } catch (Exception $ex) {
            $status = FAILURE_CODE;
            $body = $ex->getMessage();
            $this->json($status, $body);
        }
    }

    public function resend_otp() {
		$this->loadModel('User');
        try {
            if (!$this->request->is(array('POST'))) {
                throw new Exception('Only POST  supported');
            }
            $required = array(
                'authorization_key' => @$this->request->header('Authorization-key'),
                'checking_exits' => 1
            );
            $notrequired = array(
            );
            $requestdata = $this->validarray($required, $notrequired);
            $options = ['conditions' => ['User.authorization_key' => $requestdata['authorization_key']]];
            $restaurant = $this->User->find('first', $options);
            $mail = [];
            $mail['to'] = $restaurant['User']['email'];
            $mail['from'] = 'Admin <admin@apphinge.com>';
            $mail['subject'] = 'Verfication Code | ' . date('M d Y H:i:s');
            $mail['body'] = 'verfication code of User account is  | ' . $restaurant['User']['otp'] . ' ' . date('M d Y H:i:s');
            $Email = $this->sendmail($mail);
            $status = SUCCESS_CODE;
            $body['message'] = "OTP send ";
            $this->json($status, $body);
        } catch (Exception $ex) {
            $status = FAILURE_CODE;
            $body = $ex->getMessage();
            $this->json($status, $body);
        }
    }

    function login_with_facebook() {
		$this->loadModel('User');
        try {
            if (!$this->request->is(array('POST'))) {
                throw new Exception('Only POST  supported');
            }
            $required = array(
                'id_facebook' => @$this->request->data['id_facebook'],
                'checking_exits' => 0
            );
            $notrequired = array(
                'photo_facebook' => @$this->request->data['photo_facebook'],
                'email' => @$this->request->data['email'],
                'name' => @$this->request->data['name'],
                'authorization_key' => $this->_generate_random_number(),
				'device_type' => @($this->request->data['device_type'] == '') ? 0 : $this->request->data['device_type'],
                'device_token' => @($this->request->data['device_token'] == '') ? '' : $this->request->data['device_token']
            );
            $requestdata = $this->validarray($required, $notrequired);
            //prx($requestdata);

            $data = $this->User->find('first', ['conditions' => ['User.id_facebook' => $requestdata['id_facebook']]]);
            $name = explode(' ', $this->request->data['name']);
            if (!empty($data)) {
                $array = [
                    'id' => $data['User']['id'],
                    'first_name' => $name[0],
                    'last_name' => $name[1],
                    'id_facebook' => $requestdata['id_facebook'],
                    'photo_facebook' => $requestdata['photo_facebook'],
                    'email' => $requestdata['email'],
                    'device_type' => $requestdata['device_type'],
                    'device_token' => $requestdata['device_token'],
                    'authorization_key' => $requestdata['authorization_key'],
                ];
                $this->User->save($array);
                $status = SUCCESS_CODE;
                $body = $this->information($requestdata['authorization_key']);
                $this->json($status, $body);
            }
            $email = $this->User->find('first', ['conditions' => ['User.email' => $this->request->data['email']]]);
            if (!empty($email)) {
                $array = [
                    'id' => $email['User']['id'],
                    'first_name' => @$name[0],
                    'last_name' => @$name[1],
                    'id_facebook' => $requestdata['id_facebook'],
                    'photo_facebook' => $requestdata['photo_facebook'],
                    'email' => $requestdata['email'],
					'device_type' => $requestdata['device_type'],
                    'device_token' => $requestdata['device_token'],
                    'authorization_key' => $requestdata['authorization_key'],
                ];
                $this->User->save($array);
                $status = SUCCESS_CODE;
                $body = $this->information($requestdata['authorization_key']);
                $this->json($status, $body);
            }
            $requestdata['first_name'] = @$name[0];
            $requestdata['last_name'] = @$name[1];
            $this->User->save($requestdata);
            $status = SUCCESS_CODE;
            $body = $this->information($requestdata['authorization_key']);
            $this->json($status, $body);
        } catch (Exception $ex) {
            $status = FAILURE_CODE;
            $body = $ex->getMessage();
            $this->json($status, $body);
        }
    }

    public function signup_user() {
		$this->loadModel('User');
        try {
            if (!$this->request->is(array('POST'))) {
                throw new Exception('Only POST  supported');
            }
            $required = array(
                'first_name' => @$this->request->data['first_name'],
                'last_name' => @$this->request->data['last_name'],
                'email' => @$this->request->data['email'],
                'username' => @$this->request->data['username'],
                'password' => @$this->request->data['password'],
                'country' => @$this->request->data['country'],
                'otp' => rand("0000", "9999"),
                'checking_exits' => 1
            );
            $notrequired = array(
                'device_type' => @($this->request->data['device_type'] == '') ? 0 : $this->request->data['device_type'],
                'device_token' => @($this->request->data['device_token'] == '') ? '' : $this->request->data['device_token'],
                'authorization_key' => $this->_generate_random_number(),
            );
            $requestdata = $this->validarray($required, $notrequired);
         
            if ($this->User->save($requestdata, ['validate' => false])) {
                $user_id = $this->User->getLastInsertId();
                $_user = $this->User->read(null, $user_id);
                @$_user['User']['image'] = $this->_upload_file($_FILES['image']);
                if ($_user['User']['image'] && strlen(trim($_user['User']['image']))) {
                    $this->User->save($_user, ['validate' => false]);
                }
                $mail = [];
                $mail['to'] = $requestdata['email'];
                $mail['from'] = 'Admin <admin@apphinge.com>';
                $mail['subject'] = 'Verfication Code | ' . date('M d Y H:i:s');
                $mail['body'] = 'verfication code of USER account is  | ' . $requestdata['otp'] . ' ' . date('M d Y H:i:s');
                $Email = $this->sendmail($mail);
                $status = SUCCESS_CODE;
                $body['authorization_key'] = $requestdata['authorization_key'];
                $this->json($status, $body);
            } else {
                throw new Exception('Error to add USER');
            }
        } catch (Exception $ex) {
            $status = FAILURE_CODE;
            $body = $ex->getMessage();
            $this->json($status, $body);
        }
    }
	
	public function forgot_password() {
		$this->loadModel('User');
        try {
            if (!$this->request->is(array('POST'))) {
                throw new Exception('Only POST  supported');
            }
            $required = array(
                'email' => @$this->request->data['email'],
                'checking_exits' => 0
            );
            $notrequired = array(
            );
            $requestdata = $this->validarray($required, $notrequired);
            $options = ['conditions' => ['User.email' => $requestdata['email']]];
            $user = $this->User->find('first', $options);
			if($user){
				$new=[
					'id' => $user['User']['id'], 
					'otp' => rand(00000,99999), 
				];
				$this->User->save($new);
				$mail = [];
				$mail['to'] = $user['User']['email'];
				$mail['from'] = 'Admin <admin@apphinge.com>';
				$mail['subject'] = 'Verfication Code | ' . date('M d Y H:i:s');
				$mail['body'] = 'verfication code of User account is  | ' . $new['otp'] . ' ' . date('M d Y H:i:s');
				$Email = $this->sendmail($mail);
			}else{
				throw new Exception("Email is not found");
			}
            $status = SUCCESS_CODE;
            $body['Authorization-key'] = $user['User']['authorization_key'];
            $this->json($status, $body);
        } catch (Exception $ex) {
            $status = FAILURE_CODE;
            $body = $ex->getMessage();
            $this->json($status, $body);
        }
    }
	
	public function chnage_password() {
		$this->loadModel('User');
        try {
            if (!$this->request->is(array('POST'))) {
                throw new Exception('Only POST  supported');
            }
            $required = array(
                'authorization_key' => @$this->request->header('Authorization-key'),
                'password' => @$this->request->data['password'],
                'checking_exits' => 0
            );
            $notrequired = array(
            );
            $requestdata = $this->validarray($required, $notrequired);
            $new=[
				'id' => $requestdata['user_id'],
				'password' => $requestdata['password'],
			];
			$this->User->save($new);	
            $status = SUCCESS_CODE;
            $body = $this->information($requestdata['authorization_key']);;
            $this->json($status, $body);
        } catch (Exception $ex) {
            $status = FAILURE_CODE;
            $body = $ex->getMessage();
            $this->json($status, $body);
        }
    }
	
	public function create_folder() {
		$this->loadModel('Folder');
        try {
            if (!$this->request->is(array('POST'))) {
                throw new Exception('Only POST  supported');
            }
            $required = array(
                'authorization_key' => @$this->request->header('Authorization-key'),
                'name' => @$this->request->data['name'],
                'image' => @$_FILES['image']['name'],
                'date' => strtotime(@$this->request->data['date']),
                'checking_exits' => 0
            );
            $notrequired = array(
            );
            $requestdata = $this->validarray($required, $notrequired);
			
			$requestdata['image']=$this->_upload_file($_FILES['image'],'','folder');	 
			if($requestdata['image']){
				$requestdata['image']=$this->_abs_url('uploads/folder/'.$requestdata['image']);
			}else{
				$requestdata['image']='';
			}
			$this->Folder->save($requestdata);	
			$requestdata['id'] = $this->Folder->getLastInsertId();
            $status = SUCCESS_CODE;
			unset($requestdata['authorization_key']);
            $body = $requestdata;
            $this->json($status, $body);
        } catch (Exception $ex) {
            $status = FAILURE_CODE;
            $body = $ex->getMessage();
            $this->json($status, $body);
        }
    }
	
	public function get_folder() {
		$this->loadModel('Folder');
        try {
            if (!$this->request->is(array('get'))) {
                throw new Exception('Only get  supported');
            }
            $required = array(
                'authorization_key' => @$this->request->header('Authorization-key'),
                'checking_exits' => 0
            );
            $notrequired = array(
            );
            $requestdata = $this->validarray($required, $notrequired);
		
			$data=$this->Folder->find('all',[
				'conditions'=>[
					'Folder.user_id' =>$requestdata['user_id']
				]
			]);
			$final=[];
			foreach($data as $k => $v){
				$final[]=$v['Folder'];
				$final[$k]['total_data']=count($v['Image']);
			}
            $status = SUCCESS_CODE;
            $body = $final;
            $this->json($status, $body);
        } catch (Exception $ex) {
            $status = FAILURE_CODE;
            $body = $ex->getMessage();
            $this->json($status, $body);
        }
    }
	
	
		public function upload_images() {
		$this->loadModel('Image');
        try {
            if (!$this->request->is(array('post'))) {
                throw new Exception('Only post  supported');
            }
            $required = array(
				'authorization_key' => @$this->request->header('Authorization-key'),
				'folder_id' => @$this->request->data['folder_id'],
				'url' => @$_FILES['url']['name'],
				'type' => @$this->request->data['type'], // 0-> images 1-> video
				'checking_exits' => 0
            );
            $notrequired = array(
				'tumb_img' =>  @$_FILES['tumb_img']['name']
            );
            $requestdata = $this->validarray($required, $notrequired);
			if (!$this->checkid('Folder', 'id', $requestdata['folder_id'])) {
                    throw new Exception('Invalid folder_id');
               }
			
			$folder=($requestdata['type']==0)?'image':'video';	
			$requestdata['url']=$this->_upload_file($_FILES['url'],'',$folder);	 
			if($requestdata['url']){
				unset($requestdata['tumb_img']);
				if($requestdata['type']==1){
					if($this->_upload_file($_FILES['tumb_img'],'',$folder)){
						$requestdata['tumb_img']=$this->_abs_url('uploads/'.$folder.'/'.$requestdata['tumb_img']);	
					}else{
						$requestdata['tumb_img']='';
					}	
				}
				$requestdata['url']=$this->_abs_url('uploads/'.$folder.'/'.$requestdata['url']);
			}else{
				$requestdata['url']='';
			}
			
			if($this->Image->save($requestdata)){	
				$requestdata['id'] = $this->Image->getLastInsertId();
				unset($requestdata['authorization_key']);
				$status = SUCCESS_CODE;
				$body = $requestdata;
				$this->json($status, $body);
			}else{
				throw new Exception("Error to upload a image");
			}
        } catch (Exception $ex) {
            $status = FAILURE_CODE;
            $body = $ex->getMessage();
            $this->json($status, $body);
        }
    }
	
	public function get_images() {
		$this->loadModel('Image');
        try {
            if (!$this->request->is(array('post'))) {
                throw new Exception('Only post  supported');
            }
            $required = array(
                'authorization_key' => @$this->request->header('Authorization-key'),
				'folder_id' => @$this->request->data['folder_id'],
				'type' => @$this->request->data['type'], // 0-> images 1-> video
                'checking_exits' => 0
            );
            $notrequired = array();
            $requestdata = $this->validarray($required, $notrequired);
			if (!$this->checkid('Folder', 'id', $requestdata['folder_id'])) {
                    throw new Exception('Invalid folder_id');
               }
			
			$data=$this->Image->find('all',[
				'conditions' => [
					'Image.folder_id' => $requestdata['folder_id'],
					'Image.type' => $requestdata['type']
				]
			]);	
			$final=[];
			foreach($data as $value){
				$final[]=$value['Image'];
			}
			if($final){
				$status = SUCCESS_CODE;
				$body = $final;
				$this->json($status, $body);
			}else{
				throw new Exception("NO result found ");
			}
        } catch (Exception $ex) {
            $status = FAILURE_CODE;
            $body = $ex->getMessage();
            $this->json($status, $body);
        }
    }
	

}
