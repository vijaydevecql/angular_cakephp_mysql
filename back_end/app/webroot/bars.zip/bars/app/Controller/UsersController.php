<?php

App::uses('AppController', 'Controller');

/**
 * Users Controller
 *
 * @property User $User
 * @property PaginatorComponent $Paginator
 */
class UsersController extends AppController {

    function beforeRender() {
        parent::beforeRender();
    }

    function beforeFilter() {
        parent::beforeFilter();
        /**
         * Stores array of deniable methods, without logging in.
         */
        $this->_deny = array(
            'admin' => array(
                'admin_index',
                'admin_posts',
                'admin_login',
                'admin_update',
                'admin_folder',
                'admin_video',
                'admin_images',
                'admin_logout',
                'admin_all_images',
            ),
        );
        $this->_deny_url($this->_deny);
    }
	
    function admin_index() {
		if(!$this->_admin_auth_check()){
			return $this->redirect('/admin/admins/login');
		}
        $this->layout = 'admin_dashboard';
		$this->set('users_listing',$this->User->find('all'));
		$this->set('page','users');
		$this->set('title','user');
    }
    
    function admin_posts() {

    	$condition = '';

    	if(isset($this->request->query['type'])){

    		$condition = "Post.type = ".$this->request->query['type'];

    	}	

		if(!$this->_admin_auth_check()){
			return $this->redirect('/admin/admins/login');
		}
		$this->layout = 'admin_dashboard';
		App::uses('Post', 'Model');
        $this->Post = new Post();

    //    prx($this->Post->find('all'));
        
        $this->set('users_listing',$this->User->find('all'));
		$this->set('posts_listing',$this->Post->find('all' , [ 'conditions' => [ $condition ] ] ) );
		$this->set('page','posts');
		$this->set('title','post');
    }
    
     function admin_add() {

     	if($this->request->is('post')){
     		$user = array(
                        'User' => array(
                            'first_name' => @$this->request->data['User']['first_name'],
                            'last_name' => @$this->request->data['User']['last_name'],
                            'mobile' => @$this->request->data['User']['mobile'],
                            'email' => @$this->request->data['User']['email'],
                            'status' =>1,
                           
                        )
                    ); 
     		if ($this->User->save($user, ['validate' => false])) {
             $id = $this->User->getLastInsertID();
        }
        else
        {
        	$id = 0;
        }
     	}
		echo $id;
		die;
    }



	function update_status(){
		$model=$this->request->data['model'];
		$this->loadModel($model);
		$condition=
		[
			'conditions' => 
			[
				$model.'.id'=>$this->request->data['id']
			],
		];
		$data=$this->{$model}->find('first',$condition);
		$new=[
			'id' => $this->request->data['id'],
		     'status' => ($data[$model]['status']==0)?1:0,
		];
		$this->{$model}->save($new);
		echo $new['status'];
		die;
	}
	
	function delete_data(){
		$model=$this->request->data['model'];
		$this->loadModel($model);
		$this->{$model}->id = $this->request->data['id'];
		if($this->{$model}->delete()){
			echo 1;
		}else{
			echo 0;
		}
		die;
	}
	
	function admin_update(){
		$model=$this->request->data['model'];
		$redirect=$this->request->data['Controller'];
		$this->loadModel($model);


		$this->{$model}->save($this->request->data);
		$this->redirect($redirect);
		
	}
	
	function admin_folder($id){
		  $this->layout = 'admin_dashboard';
	}
	
	function admin_images($id=null){
		$this->layout = 'admin_dashboard';
	}
	
	function admin_video($id=null){
		$this->layout = 'admin_dashboard';
	}
	
	function admin_all_images(){
		$this->layout = 'admin_dashboard';
	}

	function admin_is_exist(){

		$t = "false";
		if($this->request->is('post'))
		{
			$_numbers = $this->User->findByEmail($this->request->data['User']['email']);

			if(count($_numbers))
			{
				$t =  "false";
			}
			else
			{		
				$t =  "true";
			}
		}
		echo $t;
		die;
		}

		

function upload_img()
{
	$this->loadModel('Admin');
 $user_id = $this->_admin_data['id'];
 //prx($_FILES['image']);

$url = "admin" ;
 $name = "";
 $name = $this->_upload_file($_FILES['image']," ",$url,"");
 $admin['Admin']['photo'] = $name;
 $this->Admin->id = $user_id;
 if($this->Admin->save($admin))
 {
 	return true;
 }
 else
 {
return  false;
 } 
die;
}
	
}
