<?php

/**
 * Custom methods
 */


function prx($data) {
	pr($data);
	die;
}
