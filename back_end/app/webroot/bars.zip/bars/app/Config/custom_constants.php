<?php

/**
 * Project specific constants (used almost across entire application)
 */
define('APP_NAME', 'Bars');
define('APP_LOGO', 'mymemz.png');

/**
 * Dev Team details (Links/Names/Social handles/Other sections)
 */
define('DEV', 'CQLsys');
define('DEV_SITE', 'http://www.cqlsys.com');
define('DEV_TWITTER', 'https://twitter.com/CqlsysTech');
define('DEV_FACEBOOK', 'https://www.facebook.com/CqlsysTechnologies');
define('DEV_LINKEDIN', 'https://www.linkedin.com/company/cqlsys-technologies?trk=biz-companies-cym');


/* api code */

define('SUCCESS_CODE',200);
define('FAILURE_CODE',403);

/**
 * Google Maps API key
 */
define('MAP_API_KEY', 'AIzaSyDtYMExtdWonZI-S9IIW9nyHUd-mZqKL4g');

/**
 * Twilio SMS API parameters
 */
define('ACCOUNT_SID', 'AC84eb5711229b077437ca2993af0c51e4');
define('AUTH_TOKEN', '72c91421b8ffcc6f01ee57020baba1c4');
define('SENDING_NUMBER', '+12012524105');

/**
 * Mailgun SMS API parameters
 */
define('MAILGUN_API_KEY', 'key-c58a069be6d91f94336037421eeb84fb');
